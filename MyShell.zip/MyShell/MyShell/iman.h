#ifndef iman
#define iman


void iMan(char *command);

#endif