#ifndef prompt_h
#define prompt_h


void print_myprompt(char* work_dir,char* username,char* sysname);




#endif



