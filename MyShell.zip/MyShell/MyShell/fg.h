#ifndef fg_h
#define fg_h
#include "headers.h"

void fgP(pid_t bpid);


#endif