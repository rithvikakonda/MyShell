#ifndef proclore_h
#define proclore_h


void funcproclore(int rr_pid);


#endif