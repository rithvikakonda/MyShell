#ifndef sk_h
#define sk_h

void search_directory(const char *base_path, const char *search_name, bool search_files, bool search_dirs, bool exact_match, bool *found_single, bool *is_file_found, bool *is_dir_found) ;

void run_seek_command(char** mini_arg, int k) ;

#endif














