#ifndef exe_h
#define exe_h

void execute_redirection(char* cmd_redtn) ;
 void execute_PipeLine(char* CMD) ;
 void getStringUntilFirstWhitespace(const char *str, char *result) ;

#endif