#ifndef ping_h
#define ping_h
#include "headers.h"

void ping(pid_t pid,int signum);

#endif









