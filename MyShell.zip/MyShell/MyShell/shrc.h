#ifndef shrc
#define shrc

void execute_shrc();
void replace_aliases(char *command);


#endif