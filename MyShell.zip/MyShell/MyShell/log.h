#ifndef log_h
#define log_h


void funlog();
void create_file();
void copy_filecmds_tomybuf();
void add_to_file_cmd(char *cmnd);

void write_to_file();
void clear_my2dary();
void delete_log_bysemi(char*cd);
void delete_log_byamper(char*cd);

#endif

