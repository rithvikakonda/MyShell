#ifndef bg_h
#define bg_h
#include "headers.h"


void bgP(pid_t bgpid);


#endif